package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bean.Registration;
import com.dao.RegistrationDao;


@Controller
public class RegistrationController {
	@Autowired
	RegistrationDao dao;
	
	@RequestMapping("/Register")
	public String showForm(Model m) {
		m.addAttribute("rgn",new Registration());
		
		return "Register"; 
	}
	
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String save(@ModelAttribute("rgn")Registration rgn) {
		dao.insert(rgn);
		return "redirect:/SelectSubject";
	}
	
	@RequestMapping("/ViewList")
	public String ViewList(Model m) {
		List<Registration> rgnList=dao.getRegistrationDetails();
		for(Registration r:rgnList) {
			System.out.println(r.getUname());
		}
		m.addAttribute("rgnList", rgnList);
		return "ViewList";
		
	}
	
	@RequestMapping(value="/editrgn/{uname}")
	public String edit(@PathVariable String uname,Model m) {
		Registration rgn=dao.getuname(uname);
		m.addAttribute("rgn", rgn);
		return "editList";
	}
	@RequestMapping(value="/editsave",method=RequestMethod.POST)
	public String editsave(@ModelAttribute("rgn") Registration rgn) {
		dao.update(rgn);
		return "redirect:/ViewList";
	}
	@RequestMapping(value="/deletergn/{uname}")
	public String delete(@PathVariable String uname) {
		dao.delete(uname);
		return "redirect:/ViewList";
	}

}
