package com.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bean.Registration;


public class RegistrationMapper implements RowMapper<Registration> {
	@Override
	public Registration mapRow(ResultSet rs, int rowNum) throws SQLException {
		Registration rgn=new Registration();
		rgn.setUname(rs.getString("uname"));
		rgn.setPword(rs.getString("pword"));
		rgn.setUtype(rs.getString("utype"));
		rgn.setEmail(rs.getString("email"));
		return rgn;
		
		
		
	}

}
