package com.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.bean.Registration;


public class RegistrationDao {
	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	
	public int insert(Registration rgn) {
		String sql="insert into Registration(uname,pword,utype,email) values(?,?,?,?)";
		int ans=template.update(sql,rgn.getUname(),rgn.getPword(),rgn.getUtype(),rgn.getEmail());
		return ans;
		
	}
	public int update(Registration rgn) {
		String sql="update Registration set pword=?,utype=?,email=? where uname=?";
		int ans=template.update(sql,rgn.getPword(),rgn.getUtype(),rgn.getEmail(),rgn.getUname());
		return ans;
	}
	
	public int delete(String uname) {
		String sql="delete from Registration where uname=?";
		return template.update(sql,uname);
	}
	public Registration getuname(String uname) {
		String sql="select * from Registration where uname=?";
		Registration rgn=template.queryForObject(sql,new Object[] {uname},new RegistrationMapper());
		return rgn;
	}
	public List<Registration> getRegistrationDetails(){
	    String sql="select * from Registration";
	    List<Registration>rgnList=template.query(sql,new RegistrationMapper());
	    return rgnList;
	}


}
